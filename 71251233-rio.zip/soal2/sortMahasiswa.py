import random
from dataMahasiswa import data
from fungsiMahasiswa import show_data, presensi_dummy, acak_data

data = data.copy()
presensi_dummy(data)
acak_data(data)



def sort_by(data: list=data, index: str="nim",rev = False):
    maps = {
        "nim":0,
        "nama":1,
        "presensi":2,
    }
    
    # Kerjakan disini:
    x = maps[index]
    n = len(data)
    for i in range(n - 1):
        if  rev == True:
            max_idx = i
            for j in range(i + 1, n):
                if data[j][x] > data[max_idx][x]:
                    max_idx = j
            data[i], data[max_idx] = data[max_idx], data[i] 
        else:
            max_idx = i
            for j in range(i + 1, n):
                if data[j][x] < data[max_idx][x]:
                        max_idx = j
            data[i], data[max_idx] = data[max_idx], data[i]    
    
    # Jangan Dihapus
    show_data(data)

sort_by(data, "nim", rev=True)


